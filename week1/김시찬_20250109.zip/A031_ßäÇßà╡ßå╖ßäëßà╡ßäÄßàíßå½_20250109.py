n,m = map(int, input().split())
print(n*m-1)