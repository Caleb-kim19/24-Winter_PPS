word = input().strip()
print(len(word))