o = input().strip()
b = bin(int(o, 8))[2:]
print(b)