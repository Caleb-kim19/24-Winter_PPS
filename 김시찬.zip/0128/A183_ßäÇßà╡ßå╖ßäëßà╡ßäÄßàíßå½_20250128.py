print("\\    /\\")
print(" )  ( ')")
print("(  /  )")
print(" \\(__)|")