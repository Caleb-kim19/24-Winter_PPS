N = int(input())

long_count = N // 4
print("long " * long_count + "int")